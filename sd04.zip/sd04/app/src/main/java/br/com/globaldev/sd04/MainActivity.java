package br.com.globaldev.sd04;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.QueueingConsumer;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLOutput;
import java.util.Arrays;
import java.util.concurrent.TimeoutException;

public class MainActivity extends AppCompatActivity {

    Handler handler = new Handler(Looper.getMainLooper());
    private EditText news;

    String newsText =  "";

    String[] corinthias = {"corinthians","corin", "corint","thians","corinthias" ,"corinthia","mosqueteiro", "corinthiano", "gavião", "gaviao", "mosqueteiros"};
    String[] palmeiras = {"palmeiras","palmeirense","marajá","maraja", "palmeir", "meira", "porco", "suino", "suíno", "verde", "verdão", "verdao"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        news = findViewById(R.id.editText2);



        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                newsText  = news.getText().toString();

                System.out.println(newsText);

                String arr[] = newsText.split(" ");
                Boolean corint = false, palme = false;

                    for (String b: corinthias){
                        if(newsText.toLowerCase().matches("(?i).*"+(b.toLowerCase()+".*"))){
                            System.out.println("Encontrou: " +b);
                            corint = true;
                            break;
                        }
                    }

                    for (String b: palmeiras){
                        if(newsText.toLowerCase().matches("(?i).*"+(b.toLowerCase()+".*"))){
                            System.out.println("Encontrou: " +b);
                            palme = true;
                            break;
                        }
                    }

                    if(corint && palme){
                        Snackbar.make(view, "Enviando para palmeiras e corinthians", Snackbar.LENGTH_LONG)
                                .show();
                        // Manda para os dois
                        new Thread(){
                            public void run(){

                                publish("corinthians", newsText);
                                publish("palmeiras", newsText);
                            }
                        }.start();

                    }else if(corint){

                        Snackbar.make(view, "Enviando para o corinthians", Snackbar.LENGTH_LONG)
                                .show();
                        new Thread(){
                            public void run(){

                                publish("corinthians", newsText);
                            }
                        }.start();

                    }else if(palme){
                        Snackbar.make(view, "Enviando para o palmeiras", Snackbar.LENGTH_LONG)
                                .show();

                        new Thread(){
                            public void run(){

                                publish("palmeiras", newsText);
                            }
                        }.start();

                    }else {

                    }

            }
        });

    }

    public void  subscrible(){
        ConnectionFactory factory = new ConnectionFactory();
        String message;
        try {
            factory.setUri("amqp://qamprzgl:qhxNsOcxWZZmW98be09RzCnajBdhDWPy@rhino.rmq.cloudamqp.com/qamprzgl");



            //Recommended settings
            factory.setRequestedHeartbeat(30);
            factory.setConnectionTimeout(30000);

            Connection connection = factory.newConnection();
            Channel channel = connection.createChannel();

            String queue = "hello";

            QueueingConsumer consumer = new QueueingConsumer(channel);
            channel.basicConsume(queue, true, consumer);

        while (true) {
            QueueingConsumer.Delivery delivery = consumer.nextDelivery();
            message = new String(delivery.getBody());
            final String finalMessage = message;
            handler.post(new Runnable() {
                public void run() {
                    Toast.makeText(MainActivity.this, "News: "+ finalMessage, Toast.LENGTH_SHORT).show();
                }
            });
            System.out.println(" [x] Received '" + message + "'");
        }

        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (TimeoutException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void publish(String queue, String message){

        ConnectionFactory factory = new ConnectionFactory();
        try {
            //Victor
            //factory.setUri("amqp://dggwyjqb:v0FXCaTGv3M4hfzqbo6MjhoFIy-hc92-@raven.rmq.cloudamqp.com/dggwyjqb");

            //Renan
            factory.setUri("amqp://qamprzgl:qhxNsOcxWZZmW98be09RzCnajBdhDWPy@rhino.rmq.cloudamqp.com/qamprzgl");


            //Recommended settings
            factory.setRequestedHeartbeat(30);
            factory.setConnectionTimeout(30000);

            Connection connection = factory.newConnection();
            Channel channel = connection.createChannel();

            boolean durable = false;    //durable - RabbitMQ will never lose the queue if a crash occurs
            boolean exclusive = false;  //exclusive - if queue only will be used by one connection
            boolean autoDelete = false; //autodelete - queue is deleted when last consumer unsubscribes

            channel.queueDeclare(queue, durable, exclusive, autoDelete, null);

            String exchangeName = "";
            String routingKey = queue;
            channel.basicPublish(exchangeName, routingKey, null, message.getBytes());
            System.out.println(" [x] Sent '" + message + "'");


        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (TimeoutException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
